﻿using System;
using System.Speech.Synthesis;

namespace chatbout___Console_App
{
    class Program
    {
        static SpeechSynthesizer synthesizer = new SpeechSynthesizer(); // Reuse the synthesizer

        static void Main(string[] args)
        {
            GreetUser();
            Console.WriteLine("\nHello! Welcome to the Cybersecurity Awareness Bot.");
            string userName = GetUserInput("What is your name? ");
            string name = Console.ReadLine();

            Console.WriteLine($"\nNice to meet you, {name}!");
            string userPurpose = GetUserInput(" What can I help you with today? ");

            RespondToUser(userPurpose);
            GetFeedback();
        }

        static void GreetUser()
        {
            // Text-to-speech greeting
            synthesizer.Speak("Hello! Welcome to the Cybersecurity Awareness Bot. I'm here to help you stay safe online.");

            // ASCII Art
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine(@"
          _    _       _           
         | |  | |     | |          
         | |__| | __ _| | ___ _ __  
         |  __  |/ _` | |/ _ \ '_ \ 
         | |  | | (_| | |  __/ | | |
         |_|  |_|\__, |_|\___|_| |_|
                 __/ |               
                |___/                
            ");
            Console.ResetColor();
        }

        static string GetUserInput(string prompt)
        {
            Console.Write(prompt);
            return Console.ReadLine();
        }

        static void RespondToUser(string userPurpose)
        {
            Console.ForegroundColor = ConsoleColor.Green;
            string response;
            // Basic response system
            while (true)
            {
                Console.Write("\nAsk me about cybersecurity: ");
                string input = Console.ReadLine()?.ToLower();

                if (string.IsNullOrWhiteSpace(input))
                {
                    Console.WriteLine("I didn't quite understand that. Could you rephrase?");

                    continue;
                }

                if (input == "exit")
                {
                    Console.WriteLine("Goodbye! Stay safe online.");

                    break;
                }

                // Cybersecurity responses
                switch (input)
                {
                    case "how are you":
                        Console.WriteLine("I'm just a bot, but I'm always ready to help!");

                        break;
                    case "what’s your purpose":
                        Console.WriteLine("I'm here to provide cybersecurity tips and answer your questions.");

                        break;
                    case "password safety":
                        Console.WriteLine("Use strong passwords with letters, numbers, and symbols. Enable two-factor authentication!");

                        break;
                    case "phishing":
                        Console.WriteLine("Beware of fake emails! Always verify links before clicking.");

                        break;
                    case "safe browsing":
                        Console.WriteLine("Use HTTPS websites and avoid downloading from untrusted sources.");

                        break;
                    default:
                        Console.WriteLine("I don't have an answer for that yet. Try asking about cybersecurity topics!");

                        break;
                }
            }
        }
        Console.WriteLine(response);
            Speak(response); // Speak the response
        Console.ResetColor();
        }

        static void GetFeedback()
        {
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("On a scale of 1 to 5, how would you rate my response?");
            string feedback = Console.ReadLine();

            // Input Validation for feedback
            if (int.TryParse(feedback, out int rating) && rating >= 1 && rating <= 5)
            {
                Console.WriteLine($"Thank you for your feedback: {rating}. I hope to improve!");
                Speak($"Thank you for your feedback: {rating}. I hope to improve!");
            }
            else
            {
                Console.WriteLine("Invalid input. Please enter a number between 1 and 5.");
                Speak("Invalid input. Please enter a number between 1 and 5.");
            }
            Console.ResetColor();
        }

        static void Speak(string text)
        {
            synthesizer.Speak(text);
        }
    }
}

