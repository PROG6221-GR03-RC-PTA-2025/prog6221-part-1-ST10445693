﻿// See https://aka.ms/new-console-template for more information
using System;
using System.Speech.Synthesis;
using System.Collections.Generic;

namespace CybersecurityAwarenessBot
{
    class Program
    {
        // System components
        private static SpeechSynthesizer synthesizer = new SpeechSynthesizer();

        // User data
        private static string userName = "";
        private static string userInterest = "";

        // Cybersecurity knowledge base
        private static readonly Dictionary<string, List<string>> cybersecurityTips = new Dictionary<string, List<string>>()
        {
            { "phishing", new List<string> {
                "Be cautious of emails asking for personal information.",
                "Don't click on suspicious links or attachments.",
                "Scammers often disguise themselves as trusted organizations.",
                "Verify email senders by checking the complete email address, not just the display name."
            }},
            { "password", new List<string> {
                "Use strong, unique passwords for each account.",
                "Avoid using personal details in your passwords.",
                "Consider using a password manager to generate and store complex passwords.",
                "Enable multi-factor authentication whenever possible."
            }},
            { "privacy", new List<string> {
                "Review privacy settings on your accounts regularly.",
                "Avoid oversharing personal information online.",
                "Use privacy-focused browsers and search engines when possible.",
                "Be mindful of what you post on social media."
            }},
            { "browsing", new List<string> {
                "Always look for HTTPS in website URLs.",
                "Use browser extensions that block malicious sites.",
                "Keep your browser and plugins updated.",
                "Clear your browsing history and cookies regularly."
            }},
            { "malware", new List<string> {
                "Install reputable antivirus software and keep it updated.",
                "Be cautious when downloading files from the internet.",
                "Regularly scan your system for malware.",
                "Keep your operating system updated with the latest security patches."
            }}
        };

        static void Main(string[] args)
        {
            try
            {
                InitializeApplication();
                RunMainLoop();
            }
            catch (Exception ex)
            {
                HandleCriticalError(ex);
            }
            finally
            {
                TerminateApplication();
            }
        }

        private static void InitializeApplication()
        {
            Console.Title = "Cybersecurity Awareness Chatbot";
            synthesizer.SetOutputToDefaultAudioDevice();
            synthesizer.Rate = 1;

            DisplayWelcomeScreen();
            userName = GetValidatedInput("What is your name? ", input => !string.IsNullOrWhiteSpace(input));

            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine($"\nWelcome, {userName}! I'm here to help you with cybersecurity best practices.");
            Console.ResetColor();

            Speak($"Welcome {userName}! I'm your cybersecurity assistant. Let's get started.");
        }

        private static void DisplayWelcomeScreen()
        {
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine(@"
          ██████╗██╗   ██╗██████╗ ███████╗███████╗███████╗
         ██╔════╝██║   ██║██╔══██╗██╔════╝██╔════╝██╔════╝
         ██║     ██║   ██║██████╔╝█████╗  █████╗  █████╗  
         ██║     ██║   ██║██╔═══╝ ██╔══╝  ██╔══╝  ██╔══╝  
         ╚██████╗╚██████╔╝██║     ███████╗██║     ███████╗
          ╚═════╝ ╚═════╝ ╚═╝     ╚══════╝╚═╝     ╚══════╝
           [ Defend | Secure | Prevent ] STAY SAFE 
            ");
            Console.ResetColor();

            Console.WriteLine("\n*********************************************************");
            Console.WriteLine("        Cybersecurity Awareness Chatbot v1.0");
            Console.WriteLine("*********************************************************\n");
        }

        private static void RunMainLoop()
        {
            while (true)
            {
                DisplayMainMenu();
                string input = GetUserInput("\nEnter your choice (1-7): ").Trim().ToLower();

                if (IsExitCommand(input))
                {
                    DisplayFarewell();
                    break;
                }

                ProcessUserInput(input);
            }
        }

        private static void DisplayMainMenu()
        {
            Console.WriteLine("\nMain Menu:");
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("1. About this chatbot");
            Console.WriteLine("2. Password Safety");
            Console.WriteLine("3. Phishing Protection");
            Console.WriteLine("4. Safe Browsing");
            Console.WriteLine("5. Privacy Tips");
            Console.WriteLine("6. Malware Prevention");
            Console.WriteLine("7. Exit");
            Console.ResetColor();
            Console.WriteLine("\nYou can also type your question directly.");
        }

        private static void ProcessUserInput(string input)
        {
            if (string.IsNullOrWhiteSpace(input))
            {
                DisplayError("Please enter a valid input.");
                return;
            }

            if (DetectSentiment(input))
            {
                return;
            }

            if (input.Contains("interested in"))
            {
                RememberUserInterest(input);
                return;
            }

            switch (input)
            {
                case "1":
                    DisplayAboutInformation();
                    break;
                case "2":
                    ProvideCybersecurityTips("password");
                    break;
                case "3":
                    ProvideCybersecurityTips("phishing");
                    break;
                case "4":
                    ProvideCybersecurityTips("browsing");
                    break;
                case "5":
                    ProvideCybersecurityTips("privacy");
                    break;
                case "6":
                    ProvideCybersecurityTips("malware");
                    break;
                default:
                    HandleKeywordBasedQuery(input);
                    break;
            }
        }

        private static void DisplayAboutInformation()
        {
            string aboutText = @"
I am a Cybersecurity Awareness Chatbot designed to:
- Educate users about online threats
- Provide practical security tips
- Help you develop safer online habits

My knowledge covers:
• Password security
• Phishing detection
• Safe browsing practices
• Privacy protection
• Malware prevention

Remember: Cybersecurity is everyone's responsibility!";

            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine(aboutText);
            Console.ResetColor();
            Speak("I am your cybersecurity awareness assistant, here to help you stay safe online.");
        }

        private static void ProvideCybersecurityTips(string topic)
        {
            if (cybersecurityTips.TryGetValue(topic, out var tips))
            {
                var random = new Random();
                string tip = tips[random.Next(tips.Count)];

                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine($"\n{topic.ToUpper()} TIP: {tip}");
                Console.ResetColor();

                Speak(tip);

                if (!string.IsNullOrEmpty(userInterest) && userInterest.Equals(topic, StringComparison.OrdinalIgnoreCase))
                {
                    string personalized = $"As someone interested in {userInterest}, you might want to explore this further.";
                    Console.WriteLine(personalized);
                    Speak(personalized);
                }
            }
            else
            {
                DisplayError("Sorry, I couldn't find information on that topic.");
            }
        }

        private static void HandleKeywordBasedQuery(string input)
        {
            bool foundMatch = false;

            foreach (var topic in cybersecurityTips.Keys)
            {
                if (input.Contains(topic))
                {
                    ProvideCybersecurityTips(topic);
                    foundMatch = true;
                    break;
                }
            }

            if (!foundMatch)
            {
                DisplayError("I'm not sure I understand. Could you try rephrasing or choose a menu option?");
            }
        }

        private static bool DetectSentiment(string input)
        {
            if (input.Contains("worried") || input.Contains("scared") || input.Contains("anxious"))
            {
                string reassurance = "It's completely normal to feel concerned about online security. I'm here to help you feel more confident and protected.";
                Console.ForegroundColor = ConsoleColor.Blue;
                Console.WriteLine(reassurance);
                Console.ResetColor();
                Speak(reassurance);
                return true;
            }

            if (input.Contains("confused") || input.Contains("frustrated") || input.Contains("overwhelmed"))
            {
                string helpMessage = "Cybersecurity can seem complex, but we'll take it step by step. What specific area would you like to focus on?";
                Console.ForegroundColor = ConsoleColor.Blue;
                Console.WriteLine(helpMessage);
                Console.ResetColor();
                Speak(helpMessage);
                return true;
            }

            return false;
        }

        private static void RememberUserInterest(string input)
        {
            try
            {
                userInterest = input.Split(new[] { "interested in" }, StringSplitOptions.RemoveEmptyEntries)[1].Trim();
                if (!string.IsNullOrWhiteSpace(userInterest))
                {
                    string response = $"I'll remember you're interested in {userInterest}. Here's a relevant tip:";
                    Console.WriteLine(response);
                    Speak(response);

                    foreach (var topic in cybersecurityTips.Keys)
                    {
                        if (userInterest.Contains(topic))
                        {
                            ProvideCybersecurityTips(topic);
                            return;
                        }
                    }

                    ProvideCybersecurityTips("privacy"); // Default tip if no specific match
                }
            }
            catch
            {
                DisplayError("I couldn't determine your area of interest. Could you say something like 'I'm interested in passwords'?");
            }
        }

        private static void DisplayFarewell()
        {
            string farewell = $"\nThank you for using the Cybersecurity Awareness Chatbot, {userName}! Remember to stay vigilant online.";
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine(farewell);
            Console.ResetColor();
            Speak(farewell);

            GetUserFeedback();
        }

        private static void GetUserFeedback()
        {
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("\nBefore you go, please rate your experience (1-5):");
            Console.ResetColor();

            string feedback = Console.ReadLine();

            if (int.TryParse(feedback, out int rating) && rating >= 1 && rating <= 5)
            {
                string response = rating >= 4
                    ? "Thank you for your positive feedback! Stay safe online."
                    : "Thank you for your feedback. We'll use this to improve.";

                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine(response);
                Console.ResetColor();
                Speak(response);
            }
            else
            {
                DisplayError("Invalid rating. Feedback not recorded.");
            }
        }

        private static string GetUserInput(string prompt)
        {
            Console.Write(prompt);
            return Console.ReadLine();
        }

        private static string GetValidatedInput(string prompt, Func<string, bool> validator)
        {
            while (true)
            {
                Console.Write(prompt);
                string input = Console.ReadLine();

                if (validator(input))
                {
                    return input;
                }

                DisplayError("Invalid input. Please try again.");
            }
        }

        private static bool IsExitCommand(string input)
        {
            return input == "7" || input == "exit" || input == "quit";
        }

        private static void DisplayError(string message)
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine(message);
            Console.ResetColor();
            Speak(message);
        }

        private static void Speak(string text)
        {
            synthesizer.SpeakAsync(text);
        }

        private static void HandleCriticalError(Exception ex)
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("\nA critical error occurred:");
            Console.WriteLine(ex.Message);
            Console.WriteLine("\nThe application will now close.");
            Console.ResetColor();

            try
            {
                synthesizer.Speak("A system error occurred. The application must close.");
            }
            catch
            {
                // If speech fails, continue with shutdown
            }
        }

        private static void TerminateApplication()
        {
            synthesizer?.Dispose();
            Environment.Exit(0);
        }
    }
}
